import 'package:flutter/material.dart';

class NouvoTicketPage extends StatefulWidget {
  const NouvoTicketPage({super.key});

  @override
  State<NouvoTicketPage> createState() => _NouvoTicketPageState();
}

class _NouvoTicketPageState extends State<NouvoTicketPage> {
  final TextEditingController pariController = TextEditingController();
  final TextEditingController priController = TextEditingController();

  String tirajChwazi = "Pa gen tiraj chwazi";
  List<Map<String, dynamic>> done = [];
  double total = 0.0;
  String optionChwazi = "";

  // --- Ajoute done nan tablo ---
  void _ajouteDone() async {
    String pari = pariController.text.trim();
    String priTxt = priController.text.trim();
    if (pari.isEmpty || priTxt.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Tanpri antre pari ak pri!")));
      return;
    }

    double pri = double.tryParse(priTxt) ?? 0;
    String type = "";

    if (pari.length == 2) {
      type = "BO";
    } else if (pari.length == 3) {
      type = "LOT3";
    } else if (pari.length == 4) {
      type = await _showTypeDialog();
      if (type.isEmpty) return;
    } else {
      type = "LOT5";
    }

    setState(() {
      done.add({
        'type': type,
        'pari': pari,
        'pri': pri,
        'option': optionChwazi,
        'checked': false,
      });
      total += pri;
      pariController.clear();
      priController.clear();
      optionChwazi = "";
    });
  }

  // --- Dialog pou LOT4/MAR ---
  Future<String> _showTypeDialog() async {
    return await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        bool showLot4 = false;
        return StatefulBuilder(builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text("Chwazi tip tiraj"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!showLot4) ...[
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context, "MAR"),
                      child: const Text("MAR")),
                  ElevatedButton(
                      onPressed: () => setDialogState(() => showLot4 = true),
                      child: const Text("LOT4")),
                ] else ...[
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context, "LOT4-1"),
                      child: const Text("LOT4-1")),
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context, "LOT4-2"),
                      child: const Text("LOT4-2")),
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context, "LOT4-3"),
                      child: const Text("LOT4-3")),
                ],
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, ""), child: const Text("Anile"))
            ],
          );
        });
      },
    ).then((value) => value ?? "");
  }

  // --- Dialog pou opsyon bouton plus ---
  Future<void> _choisiOption() async {
    String? option = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text("Chwazi opsyon"),
        children: [
          SimpleDialogOption(
              onPressed: () => Navigator.pop(context, "Pointe Boule"),
              child: const Text("Pointe Boule")),
          SimpleDialogOption(
              onPressed: () => Navigator.pop(context, "Boule Paire Auto"),
              child: const Text("Boule Paire Auto")),
          SimpleDialogOption(
              onPressed: () => Navigator.pop(context, "Grappe Lotto"),
              child: const Text("Grappe Lotto")),
        ],
      ),
    );
    if (option != null) {
      setState(() {
        optionChwazi = option;
      });
    }
  }

  void _effaseLigne(int index) {
    setState(() {
      total -= done[index]['pri'];
      done.removeAt(index);
    });
  }

  void _modifyeLigne(int index) {
    TextEditingController modPari = TextEditingController(text: done[index]['pari']);
    TextEditingController modPri = TextEditingController(text: done[index]['pri'].toString());

    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: const Text("Modifye Liy"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: modPari, decoration: const InputDecoration(labelText: "Pari")),
              TextField(
                  controller: modPri,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Pri")),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("Anile")),
            ElevatedButton(
                onPressed: () {
                  setState(() {
                    double oldPri = done[index]['pri'];
                    done[index]['pari'] = modPari.text;
                    done[index]['pri'] = double.tryParse(modPri.text) ?? oldPri;
                    total = total - oldPri + done[index]['pri'];
                  });
                  Navigator.pop(context);
                },
                child: const Text("Sove"))
          ],
        );
      },
    );
  }

  void _effaseTout() {
    setState(() {
      done.clear();
      total = 0.0;
    });
  }

  void _imprime() {
    showDialog(
        context: context,
        builder: (_) => const AlertDialog(
              title: Text("Impresyon"),
              content: Text("Tikè a enprime avèk siksè ✅"),
            ));
  }

  Future<void> _choisiTiraj() async {
    String? tiraj = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text("Chwazi tiraj"),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(context, "New York"), child: const Text("New York")),
          SimpleDialogOption(onPressed: () => Navigator.pop(context, "Paris"), child: const Text("Paris")),
          SimpleDialogOption(onPressed: () => Navigator.pop(context, "Loto 6/49"), child: const Text("Loto 6/49")),
        ],
      ),
    );
    if (tiraj != null) {
      setState(() {
        tirajChwazi = tiraj;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black54,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: _effaseTout),
          IconButton(icon: const Icon(Icons.print, color: Colors.white), onPressed: _imprime),
        ],
      ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(image: AssetImage('assets/sfbl.jpg'), fit: BoxFit.cover),
        ),
        child: Container(
          color: Colors.black.withOpacity(0.3),
          padding: const EdgeInsets.fromLTRB(10, 100, 10, 20),
          child: Column(
            children: [
              // --- Tiraj chwazi a ---
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(onPressed: _choisiTiraj, child: Text(tirajChwazi)),
                ],
              ),
              const SizedBox(height: 8),
              // --- Card ak done ---
              Expanded(
                child: SingleChildScrollView(
                  child: Card(
                    color: Colors.white.withOpacity(0.12),
                    child: Padding(
                      padding: const EdgeInsets.all(6.0),
                      child: Column(
                        children: [
                          const Divider(color: Colors.white54),
                          ...done.asMap().entries.map((entry) {
                            int i = entry.key;
                            var d = entry.value;
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 2),
                              child: Row(
                                children: [
                                  Expanded(flex: 2, child: Text("Type: ${d['type']}", style: const TextStyle(color: Colors.white))),
                                  Expanded(flex: 2, child: Text(d['pari'], style: const TextStyle(color: Colors.white))),
                                  Expanded(flex: 1, child: Text("${d['pri'].toStringAsFixed(2)} HTG", textAlign: TextAlign.right, style: const TextStyle(color: Colors.white))),
                                  if(d['option'] != "") Expanded(flex: 2, child: Text(d['option'], style: const TextStyle(color: Colors.orange))),
                                  IconButton(icon: const Icon(Icons.edit, color: Colors.yellow, size: 18), onPressed: () => _modifyeLigne(i)),
                                  IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent, size: 18), onPressed: () => _effaseLigne(i)),
                                ],
                              ),
                            );
                          }),
                          Divider(color: Colors.white.withOpacity(0.6)),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Text("Total: ${total.toStringAsFixed(2)} HTG",
                                  style: const TextStyle(color: Colors.yellow, fontWeight: FontWeight.bold, fontSize: 18))),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              // --- Champs Pari / Pri + Bouton plus ---
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: pariController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.9),
                        labelText: "Pari",
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: priController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.9),
                        labelText: "Pri",
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_circle, color: Colors.green, size: 32),
                    onPressed: _choisiOption,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // --- Bouton Antre anba champs ---
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _ajouteDone,
                  child: const Text("Antre"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
