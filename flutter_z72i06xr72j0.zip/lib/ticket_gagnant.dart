import 'package:flutter/material.dart';

class TicketGagnantPage extends StatelessWidget {
  const TicketGagnantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ticket Gagnant')),
      body: const Center(
        child: Text(
          'Sa a se paj Ticket Gagnant.',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
