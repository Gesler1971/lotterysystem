import 'package:flutter/material.dart';
import 'game.dart';
import 'report.dart';
import 'config.dart';
import 'home_page.dart';

class ChecheTicketPage extends StatefulWidget {
  final String? username;
  const ChecheTicketPage({super.key, this.username});

  @override
  State<ChecheTicketPage> createState() => _ChecheTicketPageState();
}

class _ChecheTicketPageState extends State<ChecheTicketPage> {
  final TextEditingController _ticketController = TextEditingController();

  // Egzanp done pou kolòn
  final List<Map<String, dynamic>> tirajData = [
    {'Type': 'BO', 'Paris': 12, 'Pri': 100},
    {'Type': 'LOT3', 'Paris': 345, 'Pri': 500},
    {'Type': 'MAR', 'Paris': 67, 'Pri': 200},
    {'Type': 'Lot4-1', 'Paris': 1234, 'Pri': 300},
    {'Type': 'Lot4-2', 'Paris': 5678, 'Pri': 400},
    {'Type': 'Lot4-3', 'Paris': 9101, 'Pri': 600},
  ];

  void _openModal() {
    if (_ticketController.text.isEmpty) return;

    int totalPri = tirajData.fold(0, (sum, item) => sum + item['Pri'] as int);
    String currentTime = DateTime.now().toString();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Center(
          child: Container(
            width: 200, // Simile 50mm thermal paper
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 5,
                  offset: Offset(2, 2),
                )
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Titre ak ID Ticket + Heure
                  Text(
                    'Tiraj New York',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Ticket ID: ${_ticketController.text}',
                    style: const TextStyle(fontSize: 14),
                  ),
                  Text(
                    'Date/Heure: $currentTime',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 10),
                  // DataTable ak Total
                  DataTable(
                    columnSpacing: 10,
                    horizontalMargin: 0,
                    columns: const [
                      DataColumn(
                          label: Text('Type', style: TextStyle(fontSize: 12))),
                      DataColumn(
                          label: Text('Paris', style: TextStyle(fontSize: 12))),
                      DataColumn(
                          label: Text('Pri', style: TextStyle(fontSize: 12))),
                    ],
                    rows: [
                      ...tirajData.map(
                        (item) => DataRow(cells: [
                          DataCell(Text(item['Type'].toString(),
                              style: const TextStyle(fontSize: 12))),
                          DataCell(Text(item['Paris'].toString(),
                              style: const TextStyle(fontSize: 12))),
                          DataCell(Text(item['Pri'].toString(),
                              style: const TextStyle(fontSize: 12))),
                        ]),
                      ),
                      // Total
                      DataRow(
                        cells: [
                          const DataCell(Text('TOTAL',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 12))),
                          const DataCell(Text('')),
                          DataCell(Text(totalPri.toString(),
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 12))),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  // Bouton Rejwe ak Enprime
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                          onPressed: () {}, child: const Text('Rejwe')),
                      ElevatedButton(
                        onPressed: () {
                          // Preview thermal print
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('Preview Thermal Print'),
                              content: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Ticket ID: ${_ticketController.text}'),
                                    Text('Date/Heure: $currentTime'),
                                    const SizedBox(height: 10),
                                    ...tirajData.map((item) => Text(
                                        '${item['Type']} | ${item['Paris']} | ${item['Pri']}')),
                                    const Divider(),
                                    Text('TOTAL: $totalPri'),
                                  ],
                                ),
                              ),
                              actions: [
                                TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text('OK'))
                              ],
                            ),
                          );
                        },
                        child: const Text('Enprime'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _openCamera() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ouvè kamera pou scan...')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        GamePage(username: widget.username ?? 'User')),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ReportPage()),
              );
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ConfigPage()),
              );
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Akey'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Rapport'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Config'),
        ],
      ),
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/sfbl.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Contenu
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                const SizedBox(height: 10),
                // Champ ID Ticket ak icon search
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _ticketController,
                        decoration: const InputDecoration(
                          filled: true,
                          fillColor: Colors.white70,
                          labelText: 'Antre ID Ticket',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                      icon: const Icon(Icons.search, color: Colors.blue),
                      onPressed: _openModal,
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Bouton Scan
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _openCamera,
                    child: const Text('Scan'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
