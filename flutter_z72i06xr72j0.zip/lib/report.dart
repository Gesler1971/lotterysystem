import 'package:flutter/material.dart';

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rapport Page'),
      ),
      body: const Center(
        child: Text(
          'Sa a se paj Rapport ou.',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
