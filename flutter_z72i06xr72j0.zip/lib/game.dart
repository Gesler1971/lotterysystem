import 'package:flutter/material.dart';
import 'report.dart';
import 'config.dart';
import 'home_page.dart';
import 'nouvo_ticket.dart';
import 'cheche_ticket.dart';
import 'ticket_gagnant.dart';

class GamePage extends StatelessWidget {
  final String username;

  const GamePage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent, // AppBar vin transparan
         elevation: 0, //
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // Retounen nan home_page.dart
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const MyHomePage(title: 'Flutter Example App')),
              );
            },
          )
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          switch (index) {
            case 0: // Akey
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => GamePage(username: username)),
              );
              break;
            case 1: // Rapport
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ReportPage()),
              );
              break;
            case 2: // Config
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ConfigPage()),
              );
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Akey',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Rapport',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Config',
          ),
        ],
      ),
      body: Stack(
        children: [
          // Background
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/sfbl.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Content
          SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 50),
                  // Logo
                  Image.asset(
                    'assets/logo11.jpg',
                    width: 120,
                    height: 120,
                  ),
                  const SizedBox(height: 20),
                  // Byenvini + username
                  Text(
                    'Byenvini, $username!',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 40),
                  // Boutons ak koulè ak redireksyon
                  SizedBox(
                    width: 200,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const NouvoTicketPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue),
                      child: const Text('Nouvo Ticket'),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: 200,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ChecheTicketPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green),
                      child: const Text('Cheche Ticket'),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: 200,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const TicketGagnantPage()),
                        );
                      },
                      style:
                          ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      child: const Text('Ticket Gagnant'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
